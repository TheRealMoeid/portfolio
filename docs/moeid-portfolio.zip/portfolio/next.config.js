/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Allows the local SVG placeholder in /public/images to render via next/image.
    // Safe to remove once a real photo replaces the placeholder.
    dangerouslyAllowSVG: true,
  },
};

module.exports = nextConfig;
